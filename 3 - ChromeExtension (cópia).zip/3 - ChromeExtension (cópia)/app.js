//Verifica a URL
if (window.document.URL == 'http://drcalc.net/juridico.asp')
    preencher();
else if (window.confirm('Essa extensão funciona apenas para DrCalc.net.\nDeseja ser redirecionado para http://drcalc.net/juridico.asp ?')) {
    window.location.href = 'http://drcalc.net/juridico.asp';
}

function preencher() {
    
    //Declaração de variáveis
    let item = 1
    let qtdItens = document.getElementsByName("qt1")[0].value;
    alert(`A quantidade de itens atual é: ${qtdItens}`);//alerta de teste       
    let data1 = document.getElementsByName("dia1")[0].value;
    //let data1 = new Date(document.getElementsByName("dia1")[0].value);//teste:captura antiga da data,
    let valor1 = document.getElementsByName("valor1")[0].value;
    let descri1 = document.getElementsByName("descri1")[0].value;
    var descriC = String(descri1);

    //Expressão regular para validar data
    let date_regex = /^(((0[1-9]|[12][0-9]|3[01])([-.\/])(0[13578]|10|12)([-.\/])(\d{4}))|(([0][1-9]|[12][0-9]|30)([-.\/])(0[469]|11)([-.\/])(\d{4}))|((0[1-9]|1[0-9]|2[0-8])([-.\/])(02)([-.\/])(\d{4}))|((29)(\.|-|\/)(02)([-.\/])([02468][048]00))|((29)([-.\/])(02)([-.\/])([13579][26]00))|((29)([-.\/])(02)([-.\/])([0-9][0-9][0][48]))|((29)([-.\/])(02)([-.\/])([0-9][0-9][2468][048]))|((29)([-.\/])(02)([-.\/])([0-9][0-9][13579][26]bv )))$/;; 
    //validador de data, altera o valor do campo
    if (date_regex.test(data1)) {
        //alert ("Formato de data dd/mm/aaaa ok")
    }
    else{
      alert("Erro:Data Inválida")
      data1 = "Data Invalida"
    }
    //Separando a data informada, e passando para o formato americano
    let dataSplit = data1.split("/")
    let novaData = new Date();
    novaData.setDate(dataSplit[0])
    novaData.setMonth(dataSplit[1]-1)
    novaData.setFullYear(dataSplit[2])
    //alert(`Data Setada: ${novaData}`)//alerta para testar o retorno da data
      
    for (let i = 9; i <= qtdItens * 1,1; i = i + 4) {

        window.document.getElementsByClassName("cxtexto1")[i].value = valor1;
        window.document.getElementsByClassName("cxtexto1")[i - 1].value = 
        `${novaData.getDate()}/${novaData.getMonth()+1}/${novaData.getFullYear()}`;
        window.document.getElementsByClassName("cxtexto1")[i - 2].value = item;
        window.document.getElementsByClassName("cxtexto1")[i + 1].value = descriC;
        item++ //incremento do primeiro campo item
        novaData.setDate(novaData.getDate()+30)//incremento de dias da data
    }
}